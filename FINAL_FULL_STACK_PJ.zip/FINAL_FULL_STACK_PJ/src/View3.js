import React from 'react';
import cat3 from './cat3.jpg';


const View3 = () => {
  return (
    <div>
      <h2>This is an angry cat</h2>

      <img src={cat3} alt="cat3" style={{ width: '600px', height: '600px' }} />
    </div>
  );
};

export default View3;
